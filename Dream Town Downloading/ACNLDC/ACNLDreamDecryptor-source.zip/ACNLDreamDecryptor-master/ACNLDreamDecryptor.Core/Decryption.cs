﻿using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace ACNLDreamDecryptor.Core
{
    public static class Decryption
    {
        /// <summary>
        /// The key used for encryption & decryption of AC:NL dream towns.
        /// </summary>
        private static readonly byte[] AcnlAesKey = Encoding.ASCII.GetBytes("gvskivgchsuj7ifc");

        /// <summary>
        /// The default counter array (minus file-specific data) for AC:NL dream towns.
        /// </summary>
        private static readonly byte[] AcnlCtrDefault = {
            0x02, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x01
        };

        public static bool Decrypt(string filePath)
        {
            if (!File.Exists(filePath)) return false; // Invalid file

            try
            {
                // Read all file data into buffer
                var fileData = File.ReadAllBytes(filePath);

                // Copy AES128CTR counter data.
                fileData.Take(12).ToArray().CopyTo(AcnlCtrDefault, 1);

                // Create a new AES128 Counter Mode encryption object.
                using (var aes = new Aes128CounterMode(AcnlCtrDefault))
                {
                    // Decrypted file path
                    var path = Path.Combine(Path.GetDirectoryName(filePath),
                        Path.GetFileNameWithoutExtension(filePath) + "_decrypted.dat");

                    // Decrypt the file and write it.
                    var decryptor = aes.CreateDecryptor(AcnlAesKey, null);
                    using (var file = File.Create(path))
                    {
                        using (var cryptoStream = new CryptoStream(file, decryptor, CryptoStreamMode.Write))
                        {
                            // Write the encrypted data minus the 32 byte header to the crypto stream for decrypting. 
                            cryptoStream.Write(fileData, 0x20, fileData.Length - 0x20);
                        }
                    }

                    // Dispose the decryption object.
                    decryptor.Dispose();
                    return true; // Successfully decrypted the file.
                }
            }
            catch
            {
                return false;
            }
        }
    }
}
