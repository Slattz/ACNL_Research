﻿using System;
using System.IO;
using System.Net;
using System.Threading.Tasks;

namespace ACNLDreamDecryptor.Core
{
    public static class DreamDownloader
    {
        private static byte[] _fileData;

        /// <summary>
        /// Gets a buffer containing the file data for a given Dream Code.
        /// </summary>
        /// <param name="dreamCode">The Dream Code whose town will be downloaded.</param>
        /// <param name="cert">The 3DS console-unique certificate to use in the web request.</param>
        /// <param name="uid">The 3DS console-unique unique id to use in the web request.</param>
        /// <returns></returns>
        public static (bool, byte[]) Download(string dreamCode, string cert, string uid)
        {
            // TODO: Dream Code needs to be resolved to the actual URL version. The Date header also needs to be properly set.
            var request = (HttpWebRequest) WebRequest.Create($"https://ctr-egdj2-live.s3.amazonaws.com/10.CTR_EGDJ_datastore/ds/1/data/{dreamCode}");
            request.Method = "GET";
            request.Timeout = 3000;

            // Setup request headers
            request.Headers["User-Agent"] = "CTR-NEX/3.10.17.2007 PID=133001580 Region=EUR(2) Country=FR(77) AreaCode=Unknown";
            request.Headers["Date"] = "Fri, 05 Oct 2018 14:37:38 GMT";
            request.Headers["Host"] = "ctr-egdj2-live.s3.amazonaws.com";

            // Request a response via the request & let the callback handle it.
            var result = request.BeginGetResponse(DreamAsyncCallback, request);

            // Wait for the async call to complete. This blocks execution of the current thread.
            result.AsyncWaitHandle.WaitOne();
            return _fileData == null ? (false, null) : (true, _fileData);
        }

        /// <summary>
        /// Secondary method to download dream town data. This method is probably better. No way to calculate percentage though.
        /// </summary>
        /// <param name="dreamCode"></param>
        /// <param name="cert"></param>
        /// <param name="uid"></param>
        /// <returns></returns>
        public static async Task<byte[]> Download2(string dreamCode, string cert, string uid)
        {
            using (var client = new WebClient())
            {
                client.Headers["User-Agent"] = "CTR-NEX/3.10.17.2007 PID=133001580 Region=EUR(2) Country=FR(77) AreaCode=Unknown";
                client.Headers["Date"] = "Fri, 05 Oct 2018 14:37:38 GMT";
                client.Headers["Host"] = "ctr-egdj2-live.s3.amazonaws.com";

                return await client.DownloadDataTaskAsync($"https://ctr-egdj2-live.s3.amazonaws.com/10.CTR_EGDJ_datastore/ds/1/data/{dreamCode}");
            }
        }

        /// <summary>
        /// Async callback for the <see cref="HttpWebRequest"/> object's response.
        /// </summary>
        /// <param name="result">The <see cref="IAsyncResult"/> of the HttpWebRequest's response.</param>
        private static void DreamAsyncCallback(IAsyncResult result)
        {
            // These values can be exposed if we would like to draw a progress bar.
            long total = 0;
            long received = 0;
            var request = (HttpWebRequest) result.AsyncState;

            try
            {
                using (var response = (HttpWebResponse) request.EndGetResponse(result))
                {
                    var buffer = new byte[1024];

                    using (var stream = response.GetResponseStream())
                    {
                        if (stream != null)
                        {
                            total = stream.Length;
                            long size = stream.Read(buffer, 0, buffer.Length);

                            using (var memoryStream = new MemoryStream())
                            {
                                while (size > 0)
                                {
                                    memoryStream.Write(buffer, 0, (int) size);
                                    received += size;

                                    size = stream.Read(buffer, 0, buffer.Length);
                                }

                                _fileData = memoryStream.ToArray();
                                request.EndGetResponse(result);
                            }
                        }
                        else
                        {
                            _fileData = null;
                        }
                    }
                }
            }
            catch
            {
                _fileData = null;
            }
        }
    }
}
