﻿using System;
using System.IO;
using ACNLDreamDecryptor.Core;

namespace ACNLDreamDecryptor.CommandLine
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            if (args == null || args.Length < 1)
            {
                Console.WriteLine("Enter the path to the AC:NL Dream Town File:");
                args = new[] { Console.ReadLine()?.Replace("\"", "") };
            }

            if (!File.Exists(args[0])) return; // Invalid file

            Console.WriteLine(Decryption.Decrypt(args[0])
                ? "Successfully decrypted the dream town file!"
                : "Failed to decrypt the dream town file!");

            Console.WriteLine("Press any key to close this window...");
            Console.ReadKey();
        }
    }
}
